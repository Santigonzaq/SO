---------------------------------------------------------
Visor de archivos en PHP
Santiago González Quiros 
Daniel Hoyos González 1037661200
---------------------------------------------------------
Instalación:
1-Es necesario tener xampp instalado en linux para correr el visor https://www.apachefriends.org/es/download.html
2-Mover la carpeta core e index.php a /opt/lampp/htdocs
3- Una vez instalado, debemos otorgarle a la carpeta /opt/lampp/htdocs/ todos los permisos (777)
4-Una vez hecho esto, se puede acceder mediante la ruta localhost en el navegador al programa.

