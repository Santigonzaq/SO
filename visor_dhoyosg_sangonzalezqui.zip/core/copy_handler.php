<?php
   if(isset($_POST['submit'])){
       $cType = $_POST['cType'];
       $origin = $_POST['origin'];
       $src = $_POST['src'];
       if($cType == "copy"){
           `cp -ar $origin $src`;
       }else{
           `mv $origin $src`;
       }
       header('Location: ' . $_SERVER['HTTP_REFERER']);
       exit;
    }
?>