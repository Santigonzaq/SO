<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sistema de archivos</title>
    <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="verificacion.js"></script>
    <link rel="stylesheet" href="so.css">
</head>

<body>
  <div id="general">
   <h1>Sistema de archivos</h1>
   <div id="listado">
     
      <ul id="listaitems">
        <?php
            if($_GET['url'] != "" and $_GET['name'] != ""){
                $dir = $_GET['url'];
                $name = $_GET['name'];
                $ficheros  = scandir($dir."/".$name);
                foreach($ficheros as $value){
                    if ($value != "." and $value !=".."){
                        if (is_dir($dir."/".$name."/".$value)){
                            echo "<li><a href='/core/edit_handler.php?name=".$value."&url=".$dir."/".$name."'>".$value."</a></li>";
                        }else{
                            echo "<li>".$value."</li>";
                        }
                    }
                }
            }
        ?> 
          
      </ul>
      
       
       
   </div>
   
   <div id="crear">
      <p>CREAR O ELIMINAR</p>
      
      <button id="createlement">Crear Archivo o carpeta</button>
      
   
   
     <div id="create">
      <form id="datos" method ="POST" action="create_handler.php">
        <div>
            <select name="type">
              <option value="folder">Carpeta</option>
              <option value="file">Archivo</option>
            </select>
        </div>
        <div><br>
        <label for="nombre">
        
         <input name="nombre" id="nombre" type="text" placeholder="Nombre de la carpeta o archivo">
         </label>
         </div>
         
         <div><br>
         <label for="permisos">
         <input name="permisos" type="number" id="permisos" placeholder="permisos 777">
         </label>
             <input name="url" type="text" id="fake" value="<?php echo $dir."/".$name;?>">

         </div>
         
         <br>
         <button id="enviar" type="submit" name="submit" value="Submit">Crear Elemento</button>
          
      </form>
   </div>
    </div>
    </div>
    
        <div id="delete">
      <p>ELIMINAR ELEMENTO</p>
      <button id="deleteelement"> Eliminar un archivo o carpeta</button>
      <form id="eliminar" method="POST" action="delete_handler.php">
      <div><br>
      <label for="nombreeliminar">
          <select name="delname">
              <?php
                $ficheros  = scandir($dir."/".$name);
                foreach($ficheros as $value){
                    if ($value != "." and $value != ".." and $value !="core" and $value !="index.php"){
                        echo "<option value='".$value."'>".$value."</option>";
                    }
                }
              ?>
          </select> 
          <input name="url" type="text" id="fake" value="<?php echo $dir."/".$name;?>">
      </label>
      </div>
      <br>
      <button id="eliminar2" type="submit"  name="submit" value="Submit">Eliminar Elemento</button>

      </form>

    </div>  
<div id="copiarpegar">
         <p>COPIAR-PEGAR  //  CORTAR-PEGAR  //  RENOMBRAR</p>
         <button id="copypaste">Copiar-Cortar archivo o carpeta</button>
         <button id="rename">Renombrar archivo</button> 
        
        <form id="datoscopiar" action="copy_handler.php" method="POST">
             <label for="origen">Origen:
                <br>
                 <select id="origen" name="origin" >
                     <?php
                         include 'get_all.php';
                         $allInHtdocs= getDirContents("/opt/lampp/htdocs/");
                         foreach($allInHtdocs as $value){
                            if (strpos($value, '/core') !== false or strpos($value, '/index.php') !== false) {
                               
                            }else{
                                echo "<option value='".$value."'>".$value."</option>";    
                            }
                         }
                     ?>

                 </select>
             </label>
             <br>
             <label for="destino"> Destino:
                <br>
                 <select id="destino" name="src" >
                    <?php
                         foreach($allInHtdocs as $value){
                            if (strpos($value, '/core') !== false or strpos($value, '/index.php') !== false) {
                               
                            }else{
                                echo "<option value='".$value."'>".$value."</option>";    
                            }
                         }
                     ?>
                 </select>
             </label>
             <br>
             <br>
            <label>
                <input type="radio" name="cType" value="copy"> Copiar
            </label>
            <label>
                <input type="radio" name="cType" value="cut"> Cortar
            </label>
             <button id="acopiarsedijo" type="submit" name="submit" value="Submit">Enviar</button>
             
             
                       
         </form>
         
         
         <form  id="renameform" action="rename_handler.php" method="POST">
            
            
               <label for="origerename">Elemento a renombrar:
                <br>
                 <select id="origenrename" name="dir" >
                    <?php
                        foreach($allInHtdocs as $value){
                            if (strpos($value, '/core') !== false or strpos($value, '/index.php') !== false) {
                               
                            }else{
                                echo "<option value='".$value."'>".$value."</option>";    
                            }
                         }
                    ?>
                 </select>
             </label>
             <br>
             
             <label for="newname"> Nuevo nombre:
                <br>
                 <input type="text" name= "newname" id="newname" placeholder="Nuevo nombre">
             </label>
             <br>
             
             <br>
             <button id="arenombrar" type="submit" name="submit" value="Submit">Renombrar</button>
            
             
             
         </form>
         
         
   </div>
   
   <div id="modpermisos">
      <p>MODIFICAR PERMISOS</p>
       <button id="repermiso">Modificar permisos</button>
       
       <form id="newpermisos" action="perm_handler.php" method="POST">
           
            <label for="origerepermiso">Elemento a modificar permisos:
                <br>
                 <select id="origenrepermiso" name="source" >
                    <?php
                         foreach($allInHtdocs as $value){
                            if (strpos($value, '/core') !== false or strpos($value, '/index.php') !== false) {
                               
                            }else{
                                echo "<option value='".$value."'>".$value."</option>";    
                            }
                         }
                     ?>
                 </select>
             </label>
             <br>
             
             <label for="nuevos"> Nuevos permisos (###):
                <br>
                 <input type="text" id="nuevos" name="perm" placeholder="nuevos ej: 754">
             </label>
             <br>
             
             <br>
             <button id="modificar" type="submit" name="submit" value="Submit">Modificar permisos</button>
            
           
           
       </form>
       
   </div>
    
</body>
</html>