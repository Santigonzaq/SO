<?php
    if(isset($_POST['submit'])){
        if ($_POST['url']==""){
            $dir = "/opt/lampp/htdocs/";    
        }else{
            $dir = $_POST['url']."/";
        }
        
        $name = $_POST['delname'];
        if ($name !="index.php" and $name !="core"){
            if (is_dir($dir.$name)){
                `rm -R $dir$name`;
            }else{
                `rm $dir$name`;
            }
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
?>