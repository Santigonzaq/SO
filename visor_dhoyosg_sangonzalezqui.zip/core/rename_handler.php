<?php
    if (isset($_POST['submit'])){
        $dir = $_POST['dir'];
        $newname = $_POST['newname'];
        if (is_dir($dir)){
            $split = explode("/",$dir);
            $auxS = "";
            for($i = 0; $i <sizeof($split)-1; $i++){
                if($i == 0){
                    $auxS .=$split[$i];
                }else{
                    $auxS .="/".$split[$i];
                }
                
            }
            $auxS .="/".$newname;
            `mv $dir $auxS`;
        }else{
            $split = explode("/",$dir);
            $auxS = "";
            $ext = explode(".",$split[sizeof($split)-1])[1];
            for($i=0; $i < sizeof($split)-1;$i++){
                if($i==0){
                    $auxS .=$split[$i];
                }else{
                    $auxS .="/".$split[$i];
                }
            }
            $auxS .="/".$newname.".".$ext;
            `mv $dir $auxS`;
        }
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
?>