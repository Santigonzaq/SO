<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sistema de archivos</title>
    <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="verificacion.js"></script>
    <link rel="stylesheet" href="so.css">
</head>

<body>
  <div id="general">
   <h1>Sistema de archivos</h1>
   <div id="listado">
     
      <ul id="listaitems">
        <li>ARCHIVO O CARPETA 1</li>
        <li> ARCHIVO O CARPETA 2</li>
        <li> ARCHIVO O CARPETA 3</li>
        <li> ARCHIVO O CARPETA 4</li>      
          
      </ul>
      
       
       
   </div>
   
   <div id="crear">
      <p>CREAR O ELIMINAR</p>
      
      <button id="createlement">Crear Archivo o carpeta</button>
      
   
   
     <div id="create">
      <form id="datos" action="#">
        <div><br>
        <label for="nombre">
        
         <input id="nombre" type="text" placeholder="Nombre de la carpeta o archivo">
         </label>
         </div>
         
         <div><br>
         <label for="permisos">
         <input type="number" id="permisos" placeholder="permisos 777">
         </label>
         </div>
         
         <br>
         <button id="enviar" type="submit">Crear Elemento</button>
          
      </form>
   </div>
   
   
   <div id="delete">
       <form action="#" id="eliminar">
           
           
       </form>
       
       
       
       
   </div>
   
   
    </div>
    </div>
</body>
</html>