<?php
    if(isset($_POST['submit'])){
        if ($_POST['url'] == ""){
            $directorio = '/opt/lampp/htdocs/';
        } else {
            $directorio = $_POST['url']."/";
        }
        $type = $_POST['type'];
        $nombre = $_POST['nombre'];
        $permisos = $_POST['permisos'];
        
        if ($type == 'file'){
            `touch $directorio$nombre`;
            `chmod $permisos $directorio$nombre`;
        }else {
            `mkdir $directorio$nombre`;
            `chmod $permisos $directorio$nombre`;
        }
        #header("Location: http://localhost");
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
?>