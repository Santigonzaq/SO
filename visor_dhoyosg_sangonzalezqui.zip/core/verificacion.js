
$(document).ready(function(){
//Variables para obtener elementos del DOM    
var crearelemento=$("#createlement");
var formulariocrear=$("#create");
var divcrear=$("#crear");
var enviar=$("#enviar");


  //Función con evento para mostrar el formulario de crear carpeta y expandir el div general
    crearelemento.click(function(){
    console.log("Activo formulario crear");
    divcrear.css("height","280px");    
    formulariocrear.css("display","block");

})
    enviar.click(function(){
        console.log("oeee")
        formulariocrear.css("display","none");
        divcrear.css("height","initial");
        
    })
    
var eliminarelemento=$("#deleteelement");
var formularioeliminar=$("#delete");
var envioeliminar=$("#eliminar2"); 
var mostrarfomulario=$("#eliminar");
eliminarelemento.click(function(){
    
    console.log("Activo formulario eliminar");
    formularioeliminar.css("height","280px");    
    mostrarfomulario.css("display","block");
        
        
    })
envioeliminar.click(function(){
        
    mostrarfomulario.css("display","none");
    formularioeliminar.css("height","initial");    
})
    
    
var botonactivarcopi=$("#copypaste");
var divcopiar=$("#copiarpegar");
var fomulariocopiar=$("#datoscopiar");
var botondecopiar=$("#acopiarsedijo")
    botonactivarcopi.click(function(){
        divcopiar.css("height","300px");
        fomulariocopiar.css("display","block");
        
        
    })
    botondecopiar.click(function(){
        fomulariocopiar.css("display","none")
        divcopiar.css("height","initial")
    })
    
var botonactivarcut=$("#cortarpegar");
var fomulariocortar=$("#cutpaste");
var botondecortar=$("#acortarypegar");

botonactivarcut.click(function(){
    divcopiar.css("height","300px");
    fomulariocortar.css("display","block")
})
   botondecortar.click(function(){
       fomulariocortar.css("display","none");
        divcopiar.css("height","initial");
       
   })
    
var botonactivarrename=$("#rename");
var fomulariorename=$("#renameform");
var botonderename=$("#arenombrar");    
    
    botonactivarrename.click(function(){
         divcopiar.css("height","300px");
        fomulariorename.css("display","block");
    })
    
    botonderename.click(function(){
        fomulariocortar.css("display","none");
        divcopiar.css("height","initial");
        
    })
var divpermisos=$("#modpermisos")
var botonpermisos=$("#repermiso");
var fomulariopermiso=$("#newpermisos");
var botonderename=$("#modificar"); 

botonpermisos.click(function(){
    divpermisos.css("height","300px");
    fomulariopermiso.css("display","block");
    
})
botonderename.click(function(){
    fomulariopermiso.css("display","none");
    divpermisos.css("height","initial");
    
})

        
    
})

