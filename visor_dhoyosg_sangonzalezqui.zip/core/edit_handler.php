<?php
    if ($_GET['name'] != ""){
        $dir = $_GET['url'];
        $name = $_GET['name'];
        if(is_dir($dir."/".$name)){
            echo "sisas";
            $ficheros  = scandir($dir."/".$name);
            header("Location: "."/core/folder_view.php?name=".$name."&url=".$dir);
            die();
        }else{
            echo "nada no es folder xD";
        }
    }
?>

