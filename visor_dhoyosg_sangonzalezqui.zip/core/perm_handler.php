<?php
    if(isset($_POST['submit'])){
        $dir = $_POST['source'];
        $perm = $_POST['perm'];
        `chmod $perm $dir`;
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
?>